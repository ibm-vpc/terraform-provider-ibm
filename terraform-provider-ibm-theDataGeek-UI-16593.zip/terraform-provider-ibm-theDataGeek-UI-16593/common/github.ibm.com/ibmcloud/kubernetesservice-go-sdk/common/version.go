package common

// Version of the SDK
const Version = "0.0.1"
