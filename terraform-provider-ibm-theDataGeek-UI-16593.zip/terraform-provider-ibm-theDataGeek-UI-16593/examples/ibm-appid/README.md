# IBM App-ID example

This example shows how to setup App-ID service instance.
In this example, an app-id instance is created in given region

To run, configure your IBM Cloud provider.

Running the example

For planning phase

```shell
terraform plan
```

For apply phase

```shell
terraform apply
```

For destroy

```shell
terraform destroy
```