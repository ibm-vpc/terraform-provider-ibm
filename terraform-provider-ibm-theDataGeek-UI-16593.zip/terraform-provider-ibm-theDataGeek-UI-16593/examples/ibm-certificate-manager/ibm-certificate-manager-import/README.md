# IBM Certificate Manager Import Certificate example

This example shows how to Import a Certificate onto the Certificate Manager Instance.

To run, configure your IBM Cloud provider

Running the example

For planning phase

```shell
terraform plan
```

For apply phase

```shell
terraform apply
```

For destroy

```shell
terraform destroy
```
