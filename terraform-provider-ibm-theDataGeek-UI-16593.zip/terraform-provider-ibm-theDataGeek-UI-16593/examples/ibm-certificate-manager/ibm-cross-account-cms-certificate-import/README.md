# IBM Certificate Manager import Certificate accross IBM-CLoud accounts example
This example shows how to Import a Certificate from the Certificate Manager Instance of one account to other.

To run, configure your IBM Cloud provider

Running the example

For planning phase

```shell
terraform plan
```

For apply phase

```shell
terraform apply
```

For destroy

```shell
terraform destroy
```
