function main(params) {
  return {payload:  'Hello, ' + params.name + ' from ' + params.place};
}
