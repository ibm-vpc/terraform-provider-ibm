#!/bin/sh

echo "Hello World"

#exec docker-entrypoint.sh npm start
